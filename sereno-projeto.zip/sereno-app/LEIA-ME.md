# Sereno — Sistema de gestão para consultório de psicologia

Aplicação web completa e funcional, organizada em arquivos separados por responsabilidade, que roda em qualquer navegador moderno sem instalação. O sistema inicia **completamente vazio**: no primeiro acesso é criada a conta do administrador e, a partir dela, o próprio usuário cadastra profissionais, pacientes, consultas e lançamentos.

## Estrutura do projeto

```
sereno/
├── index.html          Estrutura da página: login, primeiro acesso e casca da aplicação
├── css/
│   └── styles.css      Todo o visual: tokens de cor, tipografia, componentes e responsividade
├── js/
│   ├── core.js         Núcleo: utilidades, estado global, permissões (RBAC), persistência e auditoria
│   ├── dashboard.js    Painel inicial: indicadores, gráficos e consultas do dia
│   ├── agenda.js       Agenda semanal, consultas, confirmações e exportação .ics
│   ├── pacientes.js    Cadastro, ficha do paciente, prontuário, documentos e LGPD
│   ├── financeiro.js   Receitas, despesas, fluxo de caixa e emissão de recibos
│   ├── relatorios.js   Relatórios consolidados e exportações CSV
│   ├── portal.js       Área do paciente: consultas, documentos e recibos
│   ├── app.js          Sessão, navegação, modais e inicialização
│   └── config.js       Configurações do consultório, usuários, auditoria e backup
└── LEIA-ME.md          Este documento
```

A ordem dos scripts no `index.html` importa: `core.js` carrega primeiro (define o estado e as utilidades usadas por todos) e `app.js` por último (dispara a inicialização). Para evoluir o sistema, cada funcionalidade está isolada no seu arquivo — quem for dar manutenção encontra o financeiro inteiro em `financeiro.js`, por exemplo.

## Primeiro acesso e uso

Abra o `index.html` no navegador. Como não há dados, o sistema exibe a tela de primeiro acesso pedindo nome, e-mail, CRP (opcional) e o nome do consultório — essa primeira conta é criada com perfil de administrador. Depois disso, o caminho natural é: cadastrar a equipe em Configurações → Usuários (psicólogos e secretaria, cada um com suas permissões), cadastrar os pacientes, e agendar as consultas na Agenda. O sistema orienta esse fluxo: se você tentar agendar sem nenhum paciente cadastrado, ele avisa e leva você ao cadastro. Todos os dados criados são gravados automaticamente a cada alteração; em Configurações → Backup é possível exportar tudo em um arquivo, restaurar e também apagar todos os dados (o que devolve o sistema à tela de primeiro acesso).

Nesta versão local a senha não é validada — a autenticação real (hash de senha, recuperação, bloqueio de tentativas) faz parte da versão de produção descrita adiante.

## Entrar e criar conta (com código de cadastro)

A tela inicial da equipe tem duas abas: Entrar e Criar conta. No primeiro acesso do sistema, junto da conta do administrador, é definido um código de cadastro secreto — a partir daí, qualquer pessoa que for criar conta pela tela inicial (psicólogo ou secretária) precisa informar esse código, o que impede cadastros indevidos. O administrador pode consultar e trocar o código a qualquer momento em Configurações → Consultório, e contas de administrador só podem ser criadas por dentro do sistema, em Configurações → Usuários. O acesso dos pacientes permanece separado e inalterado, pelo link "Sou paciente".

## Anexos de arquivos

Os documentos do paciente agora aceitam arquivo de verdade (PDF, imagens, DOC, TXT), com limite de 2,5 MB por arquivo nesta versão local. O anexo fica gravado no armazenamento do navegador junto com os metadados (tipo, tamanho, autor, data) e pode ser baixado tanto pela equipe, na aba Documentos do paciente, quanto pelo próprio paciente na área dele — cada download fica registrado na auditoria. O backup completo exporta e restaura os anexos junto com os dados, e a opção "Apagar todos os dados" também remove os arquivos. Em produção, os uploads vão para armazenamento criptografado (S3 ou Google Cloud Storage) com URLs assinadas de curta validade e sem limite prático de tamanho.

## Tema claro/escuro e acessibilidade

No canto da tela ficam três controles permanentes: A− e A+ ajustam o tamanho do texto de toda a interface (cinco níveis), e o botão de lua/sol alterna entre os modos claro e escuro. Na primeira visita o sistema segue automaticamente a preferência do sistema operacional; a escolha manual fica gravada e vale para os próximos acessos. Toda a paleta foi construída com variáveis de tema, então gráficos, agenda, status de consulta e a área do paciente se adaptam aos dois modos mantendo contraste adequado.

Do lado da acessibilidade: navegação completa por teclado com indicador de foco visível, link "Ir direto para o conteúdo" para quem usa teclado ou leitor de tela, janelas de diálogo com `role="dialog"` que movem o foco para o primeiro campo e o devolvem ao fechar (Esc também fecha), avisos do sistema anunciados por `aria-live`, item de menu atual marcado com `aria-current`, rótulos associados aos campos e respeito à preferência de movimento reduzido do sistema (animações desligadas automaticamente).

## Área do paciente

Na tela inicial, o link "Sou paciente" leva à área do titular: ele entra com o e-mail ou telefone que informou ao consultório e vê as próximas consultas com status, o histórico de sessões realizadas, os documentos disponibilizados (com indicação de assinatura) e os pagamentos, podendo imprimir os próprios recibos. Por sigilo profissional, o prontuário jamais aparece nessa área, e cada acesso do paciente fica registrado na trilha de auditoria. Em produção, essa área ganha login próprio com senha e link mágico por e-mail.

## Cobertura dos requisitos do briefing

Cadastro de pacientes com histórico completo: a tela Pacientes traz busca, cadastro completo (dados civis, responsável legal para menores, queixa inicial, profissional responsável, valor da sessão) e uma ficha com abas de Dados, Prontuário, Documentos, Financeiro e LGPD, além de contadores de sessões realizadas e faltas.

Agenda inteligente: visão semanal de segunda a sábado das 7h às 20h, com criação de consulta em um clique sobre o horário, detecção de conflito de horário por profissional, cinco status com cores (agendada, confirmada, realizada, faltou, cancelada), edição, cancelamento e navegação entre semanas.

Confirmação automática via WhatsApp ou e-mail: cada consulta agendada tem o botão "Enviar confirmação", que exibe a mensagem exata que seria enviada (com nome, data, hora, profissional e opções de resposta) e atualiza o status para confirmada. Nesta versão local o envio é simulado; em produção ele é disparado automaticamente pela API oficial do WhatsApp Business (Meta Cloud API) ou por e-mail transacional, com a antecedência configurada em Configurações.

Prontuário eletrônico com evolução dos atendimentos: cada paciente tem uma linha do tempo de evoluções. O registro nasce como rascunho editável; ao ser assinado, recebe carimbo de autoria com CRP, data/hora e um hash SHA-256 gerado no navegador, e fica travado contra edição — em linha com a Resolução CFP nº 11/2018 sobre registro documental. Todo acesso ao prontuário é gravado na trilha de auditoria.

Cadastro de documentos, laudos e anexos: a aba Documentos registra laudos, contratos, encaminhamentos e anexos, com tipo, autor, data e assinatura eletrônica. Nesta versão local armazenam-se os metadados; em produção o upload vai para armazenamento criptografado com URLs assinadas.

Controle financeiro: lançamentos de receitas e despesas por categoria e forma de pagamento, filtro por mês, fluxo de caixa (receitas, despesas e resultado), alerta de sessões realizadas sem pagamento registrado e conciliação direta a partir da consulta ("Registrar pagamento").

Emissão de recibos: qualquer receita gera um recibo numerado, com dados do consultório, do paciente e do profissional (com CRP), pronto para impressão ou salvamento em PDF pelo diálogo de impressão do navegador.

Dashboard com indicadores: sessões realizadas no mês com comparativo ao mês anterior, receita e despesas do mês, taxa de falta, pacientes ativos, consultas pendentes de confirmação, gráfico de sessões dos últimos seis meses, curva de receita mensal e a lista de consultas do dia com ações rápidas.

Controle de usuários e permissões: perfis de Administrador, Psicólogo e Secretária com privilégio mínimo. A regra mais sensível — secretária jamais acessa prontuário, e psicólogo vê apenas os próprios pacientes — está aplicada na interface e documentada numa matriz de permissões dentro do próprio sistema.

Backup automático dos dados: além da persistência automática a cada alteração, há exportação de backup completo em JSON e restauração a partir de arquivo. O plano de produção prevê backup diário criptografado com retenção de 30 dias e teste de restauração mensal.

Conformidade com a LGPD: consentimento registrado por paciente com data e base legal (art. 7º, I e art. 11, II, "f"), trilha de auditoria de todos os acessos e ações (quem, quando, o quê), exportação dos dados do titular para portabilidade, anonimização sob demanda preservando a guarda mínima do prontuário exigida pelo CFP, e checklist de conformidade em Configurações.

Diferenciais implementados: exportação da agenda em formato .ics, importável diretamente no Google Agenda; assinatura eletrônica de evoluções e documentos; relatórios de atendimentos por profissional, receita por categoria e assiduidade, com exportação em CSV compatível com Excel e contabilidade. A área do paciente (portal para o titular ver consultas e documentos) está prevista na fase 3 do roadmap abaixo, pois exige autenticação própria em ambiente de produção.

## Arquitetura recomendada para produção

Esta versão roda inteiramente no navegador para que você avalie fluxo, telas e regras de negócio sem depender de servidor. Para produção, a mesma interface é portada para a seguinte pilha, moderna e de fácil manutenção por qualquer equipe no futuro.

Backend em Node.js com NestJS (TypeScript) expondo API REST, com PostgreSQL como banco principal e Prisma como ORM. O modelo de dados espelha as entidades já presentes nesta versão: users, patients, appointments, clinical_records, documents, transactions, audit_logs e settings, acrescentando refresh tokens, filas de mensagens e versões de consentimento. Frontend em React com Vite, reutilizando o design system criado aqui (tokens de cor, tipografia Bricolage Grotesque/Instrument Sans e componentes). Autenticação com senha com hash Argon2, sessões via JWT de curta duração com refresh token, e autorização RBAC no servidor — as mesmas três permissões desta versão, agora impostas na API e não apenas na interface.

Segurança e LGPD em produção: TLS obrigatório, criptografia em repouso no banco e no storage, campo de evolução clínica cifrado em nível de aplicação (AES-256-GCM com chave em cofre de segredos), trilha de auditoria append-only, política de retenção alinhada às Resoluções CFP nº 01/2009 e nº 11/2018, e Termo de Consentimento versionado com aceite registrado. Documentos e anexos vão para S3 ou Google Cloud Storage com URLs assinadas de curta validade.

Confirmações automáticas: um agendador (cron) varre consultas nas próximas N horas e enfileira mensagens; um worker envia pela Meta WhatsApp Cloud API usando template aprovado, com webhook para capturar a resposta "1 — Confirmar" e atualizar o status sozinho; e-mail transacional (Resend ou SES) como canal alternativo. Integração com Google Agenda por OAuth 2.0 e sincronização bidirecional via Google Calendar API, mantendo o .ics como alternativa simples. Assinatura eletrônica de documentos com validade jurídica via integração com Clicksign ou D4Sign (padrão ICP-Brasil quando necessário).

Infraestrutura: deploy em VPS (Docker Compose) ou plataforma gerenciada (Railway/Render) com banco gerenciado, backups automáticos diários com retenção de 30 dias, monitoramento de erros (Sentry) e logs estruturados. Estimativa de custo mensal de operação para um consultório de pequeno a médio porte: entre R$ 100 e R$ 300, dominado por servidor, banco gerenciado e mensagens de WhatsApp.

## Roadmap por fases

Fase 1 (MVP, semanas 1 a 5): autenticação real, pacientes, agenda com conflitos, prontuário com trava de assinatura, RBAC no servidor e auditoria — tudo já especificado e validável nesta versão. Fase 2 (semanas 6 a 9): financeiro completo, recibos em PDF no servidor, dashboard, fila de confirmações via WhatsApp/e-mail e backups automáticos. Fase 3 (semanas 10 a 13): área do paciente com login próprio, sincronização com Google Agenda, assinatura eletrônica com validade jurídica, relatórios avançados e preparação para telepsicologia e múltiplas unidades. A estrutura de dados e a interface desta versão já foram desenhadas para acomodar as três fases sem retrabalho.
